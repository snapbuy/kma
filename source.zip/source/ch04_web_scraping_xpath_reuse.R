library(rvest)

html = read_html(x = "data/xpath.html", encoding = "utf-8")

# p태그만 추출 한다. 


# p태그에서 class가 second 인 것만 추출한다. 


# div태그에서 id가 third이면서, p태그를 추출 한다. 


## position


## text


## 배우만 추출


## 극중 역할만 추출


## ( ) 내용 추출
