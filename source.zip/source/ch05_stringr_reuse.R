# 필요한 패키지를 불러옵니다. 


# 전처리할 문자열을 할당합니다. 
# 뉴스기사: https://economist.co.kr/2021/10/12/stock/stockNormal/20211012182440025.html




