# lec1_2.r
# description

  x1<-c(1,3,5,7,9)
  
  # x1 is numeric or character?
  class(x1)
  is.numeric(x1)
  
  # integer is numeric 
  is.integer(x1)
  
  # need to define as.integer as.numeric as.character
  x2<-as.integer(x1)
  
  # length of x1
  length(x1)
  
  # x1 is a vector?
  is.vector(x1)
  
  # class - character
  "I like apple"
  class("I like apple")
  
  #help menu
  
  help(factor)
  
  help(boxplot)
  


